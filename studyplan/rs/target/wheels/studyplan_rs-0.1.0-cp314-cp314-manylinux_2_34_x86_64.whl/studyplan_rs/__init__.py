from .studyplan_rs import *

__doc__ = studyplan_rs.__doc__
if hasattr(studyplan_rs, "__all__"):
    __all__ = studyplan_rs.__all__